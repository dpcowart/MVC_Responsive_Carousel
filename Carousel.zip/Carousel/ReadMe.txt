These project files are meant to be used in conjunction with a blog post about creating a responsive MVC Image Carousel in Sitefinity. If you use them without the blog post, then you will need to register the Mvc widget using Thunder. For more info, google "Sitefinity Thunder Register Widget". Both folders, as is, are meant to be placed in the root of your project.
	
~ The Mvc folder's contents (sub-folders and files) should ALWAYS go into your corresponding Sitefinity project's Mvc folder.

~ The Custom folder and its content can be placed in the root or wherever you like, but make sure to update name spaces accordingly, as it is expecting the root. 

