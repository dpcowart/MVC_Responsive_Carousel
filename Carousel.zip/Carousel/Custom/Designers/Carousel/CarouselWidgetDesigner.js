Type.registerNamespace("SitefinityWebApp.Custom.Designers.Carousel");

SitefinityWebApp.Custom.Designers.Carousel.CarouselWidgetDesigner = function (element) {
    /* Initialize LibraryName fields */
    this._libraryName = null;
    
    /* Calls the base constructor */
    SitefinityWebApp.Custom.Designers.Carousel.CarouselWidgetDesigner.initializeBase(this, [element]);
}

SitefinityWebApp.Custom.Designers.Carousel.CarouselWidgetDesigner.prototype = {
    /* --------------------------------- set up and tear down --------------------------------- */
    initialize: function () {
        /* Here you can attach to events or do other initialization */
        SitefinityWebApp.Custom.Designers.Carousel.CarouselWidgetDesigner.callBaseMethod(this, 'initialize');
    },
    dispose: function () {
        /* this is the place to unbind/dispose the event handlers created in the initialize method */
        SitefinityWebApp.Custom.Designers.Carousel.CarouselWidgetDesigner.callBaseMethod(this, 'dispose');
    },

    /* --------------------------------- public methods ---------------------------------- */

    findElement: function (id) {
        var result = jQuery(this.get_element()).find("#" + id).get(0);
        return result;
    },

    /* Called when the designer window gets opened and here is place to "bind" your designer to the control properties */
    refreshUI: function () {
        var controlData = this._propertyEditor.get_control().Settings; /* JavaScript clone of your control - all the control properties will be properties of the controlData too */

        /* RefreshUI LibraryName */
        jQuery(this.get_libraryName()).val(controlData.LibraryName);
    },

    /* Called when the "Save" button is clicked. Here you can transfer the settings from the designer to the control */
    applyChanges: function () {
        var controlData = this._propertyEditor.get_control().Settings;

        /* ApplyChanges LibraryName */
        controlData.LibraryName = jQuery(this.get_libraryName()).val();
    },

    /* --------------------------------- event handlers ---------------------------------- */

    /* --------------------------------- private methods --------------------------------- */

    /* --------------------------------- properties -------------------------------------- */

    /* LibraryName properties */
    get_libraryName: function () { return this._libraryName; }, 
    set_libraryName: function (value) { this._libraryName = value; }
}

SitefinityWebApp.Custom.Designers.Carousel.CarouselWidgetDesigner.registerClass('SitefinityWebApp.Custom.Designers.Carousel.CarouselWidgetDesigner', Telerik.Sitefinity.Web.UI.ControlDesign.ControlDesignerBase);
