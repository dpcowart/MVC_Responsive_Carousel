using System;
using System.Linq;
using Telerik.Sitefinity.Libraries.Model;

namespace SitefinityWebApp.Mvc.Models
{
    public class CarouselWidgetModel
    {
        public CarouselWidgetModel(IQueryable<Image> imageItems)
        {
            this.ImageItems = imageItems;
        }
        
        /// <summary>
        /// Gets or sets the Library Name for the carousel.
        /// </summary>
        public string LibraryName { get; set; }

        public IQueryable<Image> ImageItems
        {
            get;
            private set;
        }
    }
}