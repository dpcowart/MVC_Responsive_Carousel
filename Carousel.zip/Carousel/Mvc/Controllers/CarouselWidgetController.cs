using System;
using System.ComponentModel;
using System.Linq;
using System.Web.Mvc;
using Telerik.Sitefinity.Mvc;
using SitefinityWebApp.Mvc.Models;
using Telerik.Sitefinity.Libraries.Model;
using Telerik.Sitefinity;
using Telerik.Sitefinity.GenericContent.Model;

namespace SitefinityWebApp.Mvc.Controllers
{
    [ControllerToolboxItem(Name = "CarouselWidget", Title = "CarouselWidget", SectionName = "MvcWidgets"), Telerik.Sitefinity.Web.UI.ControlDesign.ControlDesigner(typeof(SitefinityWebApp.Custom.Designers.Carousel.CarouselWidgetDesigner))]
    public class CarouselWidgetController : Controller
    {
        /// <summary>
        /// Gets or sets the message that will be displayed in the label.
        /// </summary>
        [Category("String Properties")]
        public string LibraryName { get; set; }

        /// <summary>
        /// This is the default Action.
        /// </summary>
        public ActionResult Index()
        {
            var items = GetImagesByAlbumFluentAPI(this.LibraryName);
            var model = new CarouselWidgetModel(items);

            if (string.IsNullOrEmpty(this.LibraryName))
                model.LibraryName = "No Library Name set in Designer";

            return View("Default", model);
        }

        /// <summary>
        /// Gets all images in a library with a status of live
        /// </summary>
        /// <returns></returns>
        private static IQueryable<Image> GetImagesByAlbumFluentAPI(string libraryName)
        {
            return App.WorkWith().Images().Where(a => a.Parent.Title == libraryName && a.Status == ContentLifecycleStatus.Live).Get();
        }
    }
}